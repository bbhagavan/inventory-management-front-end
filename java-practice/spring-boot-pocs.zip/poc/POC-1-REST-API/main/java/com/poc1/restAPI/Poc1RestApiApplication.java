package com.poc1.restAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Poc1RestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Poc1RestApiApplication.class, args);
	}

}
