package com.poc3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Poc3ProfilersApplication {

	public static void main(String[] args) {
		SpringApplication.run(Poc3ProfilersApplication.class, args);
	}

}
