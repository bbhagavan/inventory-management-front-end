package com.poc5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Poc5SecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(Poc5SecurityApplication.class, args);
	}

}
